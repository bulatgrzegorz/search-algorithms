```

BenchmarkDotNet v0.15.8, macOS Tahoe 26.5.2 (25F84) [Darwin 25.5.0]
Unknown processor
.NET SDK 11.0.100
  [Host] : .NET 11.0.0 (11.0.0, 11.0.26.53018), Arm64 RyuJIT armv8.0-a

Job=ShortRun  Toolchain=InProcessEmitToolchain  IterationCount=5  
IterationTime=200ms  LaunchCount=1  WarmupCount=3  

```
| Method     | WritesPerSecond | Algorithm | Size   | Mean         | Error         | StdDev        | Median       | Gen0   | Gen1   | Gen2   | Allocated |
|----------- |---------------- |---------- |------- |-------------:|--------------:|--------------:|-------------:|-------:|-------:|-------:|----------:|
| **StartsWith** | **0**               | **Changed**   | **Small**  |     **530.7 ns** |      **64.77 ns** |      **16.82 ns** |     **523.6 ns** | **0.0271** |      **-** |      **-** |     **245 B** |
| **StartsWith** | **0**               | **Changed**   | **Medium** |     **626.8 ns** |      **60.66 ns** |      **15.75 ns** |     **626.1 ns** | **0.0287** |      **-** |      **-** |     **245 B** |
| **StartsWith** | **0**               | **Changed**   | **Huge**   |     **763.1 ns** |      **47.73 ns** |       **7.39 ns** |     **763.2 ns** | **0.0259** |      **-** |      **-** |     **245 B** |
| **StartsWith** | **1000**            | **Changed**   | **Small**  |   **9,594.3 ns** |   **5,404.44 ns** |   **1,403.52 ns** |   **9,659.0 ns** | **0.1847** |      **-** |      **-** |    **1853 B** |
| **StartsWith** | **1000**            | **Changed**   | **Medium** |  **26,309.7 ns** |  **19,218.57 ns** |   **4,991.00 ns** |  **23,506.4 ns** | **0.5787** | **0.5064** | **0.1447** |    **8289 B** |
| **StartsWith** | **1000**            | **Changed**   | **Huge**   | **369,349.7 ns** | **817,942.42 ns** | **212,417.05 ns** | **269,102.8 ns** |      **-** |      **-** |      **-** |    **1898 B** |
