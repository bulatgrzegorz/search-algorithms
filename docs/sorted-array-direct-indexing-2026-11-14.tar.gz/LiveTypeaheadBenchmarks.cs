using BenchmarkDotNet.Attributes;
using SearchAlgorithms;
using SearchAlgorithms.Benchmarks;

// Same query sequence and first-ten consumption as TypeaheadBenchmarks, with Writer.Run added.
public class LiveTypeaheadBenchmarks
{
    [Params(Scale.Medium)] public Scale Size;
    [ParamsSource(nameof(AlgorithmNames))] public string Algorithm = "";
    public static IEnumerable<string> AlgorithmNames => Selected.AlgorithmNames;
    private ISearchAlgorithm _algorithm = null!;
    private string[] _prefixes = [], _fragments = [];
    private int _next;
    private readonly CancellationTokenSource _stop = new();
    private Task<double> _writer = Task.FromResult(0d);

    [GlobalSetup]
    public void Setup()
    {
        var all = Dataset.Load((int)Size + 1000);
        var items = all[..(int)Size];
        _algorithm = Algorithms.All[Algorithm](items);
        (_prefixes, _, _fragments) = Dataset.Queries(items);
        _writer = Task.Run(() => Writer.Run(_algorithm, all[..1000], all[(int)Size..], 1000, _stop.Token));
    }
    [GlobalCleanup]
    public async Task Cleanup()
    {
        await _stop.CancelAsync();
        Console.WriteLine($"Writer: {await _writer:N0} updates/s achieved, target 1000");
        await _algorithm.DisposeAsync();
    }
    [Benchmark] public long StartsWith() => Type(_prefixes, static (a, q) => a.GetByStartsWith(q));
    [Benchmark] public long Filter() => Type(_fragments, static (a, q) => a.Filter(q));
    private long Type(string[] queries, Func<ISearchAlgorithm, string, IReadOnlyList<string>> search)
    {
        var query = queries[_next++ % queries.Length];
        long shown = 0;
        for (var typed = 1; typed <= query.Length; typed++)
        {
            var hits = search(_algorithm, query[..typed]);
            for (var i = 0; i < Math.Min(10, hits.Count); i++) shown += hits[i].Length;
        }
        return shown;
    }
}
