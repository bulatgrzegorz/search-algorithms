```

BenchmarkDotNet v0.15.8, macOS Tahoe 26.5.2 (25F84) [Darwin 25.5.0]
Unknown processor
.NET SDK 11.0.100
  [Host] : .NET 11.0.0 (11.0.0, 11.0.26.53018), Arm64 RyuJIT armv8.0-a

Job=ShortRun  Toolchain=InProcessEmitToolchain  IterationCount=5  
IterationTime=200ms  LaunchCount=1  WarmupCount=3  

```
| Method     | WritesPerSecond | Algorithm | Size   | Mean         | Error         | StdDev       | Gen0   | Gen1   | Gen2   | Allocated |
|----------- |---------------- |---------- |------- |-------------:|--------------:|-------------:|-------:|-------:|-------:|----------:|
| **StartsWith** | **0**               | **Baseline**  | **Small**  |     **800.2 ns** |      **88.43 ns** |     **22.97 ns** | **0.0292** |      **-** |      **-** |     **244 B** |
| **StartsWith** | **0**               | **Baseline**  | **Medium** |   **1,139.1 ns** |     **204.17 ns** |     **53.02 ns** | **0.0263** |      **-** |      **-** |     **244 B** |
| **StartsWith** | **0**               | **Baseline**  | **Huge**   |   **1,792.1 ns** |     **485.00 ns** |    **125.95 ns** | **0.0271** |      **-** |      **-** |     **244 B** |
| **StartsWith** | **1000**            | **Baseline**  | **Small**  |   **2,082.8 ns** |     **135.32 ns** |     **20.94 ns** | **0.4720** |      **-** |      **-** |    **4074 B** |
| **StartsWith** | **1000**            | **Baseline**  | **Medium** |  **13,925.3 ns** |  **16,434.94 ns** |  **4,268.10 ns** | **5.0194** | **0.0810** | **0.0810** |   **44959 B** |
| **StartsWith** | **1000**            | **Baseline**  | **Huge**   | **428,449.2 ns** | **227,369.36 ns** | **35,185.66 ns** | **6.2500** | **2.0833** | **2.0833** |  **444601 B** |
