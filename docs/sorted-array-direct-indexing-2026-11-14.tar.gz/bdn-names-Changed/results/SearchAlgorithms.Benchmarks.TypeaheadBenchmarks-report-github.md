```

BenchmarkDotNet v0.15.8, macOS Tahoe 26.5.2 (25F84) [Darwin 25.5.0]
Unknown processor
.NET SDK 11.0.100
  [Host] : .NET 11.0.0 (11.0.0, 11.0.26.53018), Arm64 RyuJIT armv8.0-a

Job=ShortRun  Toolchain=InProcessEmitToolchain  IterationCount=5  
IterationTime=200ms  LaunchCount=1  WarmupCount=3  

```
| Method     | WritesPerSecond | Algorithm | Size   | Mean        | Error        | StdDev      | Gen0   | Gen1   | Gen2   | Allocated |
|----------- |---------------- |---------- |------- |------------:|-------------:|------------:|-------:|-------:|-------:|----------:|
| **StartsWith** | **0**               | **Changed**   | **Small**  |    **806.9 ns** |     **12.28 ns** |     **1.90 ns** | **0.0267** |      **-** |      **-** |     **244 B** |
| **StartsWith** | **0**               | **Changed**   | **Medium** |  **1,349.9 ns** |    **719.07 ns** |   **186.74 ns** | **0.0289** |      **-** |      **-** |     **244 B** |
| **StartsWith** | **0**               | **Changed**   | **Huge**   |  **1,871.9 ns** |    **899.61 ns** |   **233.63 ns** | **0.0268** |      **-** |      **-** |     **244 B** |
| **StartsWith** | **1000**            | **Changed**   | **Small**  |  **1,819.5 ns** |    **297.83 ns** |    **77.35 ns** | **0.0437** |      **-** |      **-** |     **471 B** |
| **StartsWith** | **1000**            | **Changed**   | **Medium** |  **3,996.1 ns** |  **1,792.67 ns** |   **465.55 ns** | **0.1093** | **0.1093** | **0.0182** |    **1332 B** |
| **StartsWith** | **1000**            | **Changed**   | **Huge**   | **17,439.9 ns** | **15,069.31 ns** | **2,331.99 ns** | **0.2067** |      **-** |      **-** |    **2083 B** |
