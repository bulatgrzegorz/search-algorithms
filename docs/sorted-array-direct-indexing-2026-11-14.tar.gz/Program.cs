using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Text.Json;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Diagnosers;
using BenchmarkDotNet.Running;
using SearchAlgorithms;
using SearchAlgorithms.Benchmarks;
using SearchAlgorithms.Tests;

CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;
if (args[0] == "verify") { await Verify(args[1..]); return; }
if (args[0] == "bdn")
{
    BenchmarkSwitcher.FromTypes([typeof(SearchBenchmarks), typeof(TypeaheadBenchmarks), typeof(LiveTypeaheadBenchmarks), typeof(MutationBenchmarks), typeof(BuildBenchmarks)])
        .Run(args[1..], DefaultConfig.Instance.AddDiagnoser(MemoryDiagnoser.Default));
    return;
}
if (args[0] == "latency") { LatencyRun.Run(args[1..]); return; }
if (args[0] == "retention")
{
    var dataset = args[1];
    var name = args[2];
    Environment.SetEnvironmentVariable("DATASET", dataset);
    var all = Dataset.Load(101_000);
    var items = all[..100_000];
    var present = items[..1000];
    var absent = all[100_000..];
    await using var algorithm = Algorithms.All[name](items);
    GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
    var before = GC.GetTotalMemory(true);
    var held = new List<IReadOnlyList<string>>();
    for (var generation = 0; generation < 5; generation++)
    {
        held.Add(algorithm.Filter(dataset == "isin" ? "0" : " "));
        // 400 pending changes cross the 390-change merge threshold at 100k items.
        for (var i = 0; i < 200; i++)
        {
            var k = (generation * 200 + i) % 1000;
            algorithm.Remove(present[k]);
            algorithm.Add(absent[k]);
            (present[k], absent[k]) = (absent[k], present[k]);
        }
    }
    var retainedBytes = GC.GetTotalMemory(true) - before;
    Console.WriteLine(JsonSerializer.Serialize(new { dataset, variant = name, snapshots = held.Count, retainedBytes,
        counts = held.Select(x => x.Count).ToArray() }));
    GC.KeepAlive(held);
    GC.KeepAlive(algorithm);
    return;
}
if (args[0] == "sustained")
{
    var dataset = args[1];
    var size = Enum.Parse<Scale>(args[2]);
    Environment.SetEnvironmentVariable("DATASET", dataset);
    var all = Dataset.Load((int)size + 20_000);
    var items = all[..(int)size];
    var fresh = all[(int)size..];
    foreach (var name in args[3].Split(','))
    {
        var algorithm = Algorithms.All[name](items);
        var totalStart = Stopwatch.GetTimestamp();
        var totalBefore = GC.GetTotalAllocatedBytes(true);
        try
        {
        for (var round = 0; round < 2; round++)
            foreach (var add in new[] { true, false })
            {
                var timings = new double[fresh.Length];
                var before = GC.GetTotalAllocatedBytes(true);
                var start = Stopwatch.GetTimestamp();
                for (var i = 0; i < fresh.Length; i++)
                {
                    var began = Stopwatch.GetTimestamp();
                    if (add) algorithm.Add(fresh[i]); else algorithm.Remove(fresh[i]);
                    timings[i] = Stopwatch.GetElapsedTime(began).TotalMicroseconds;
                }
                var us = Stopwatch.GetElapsedTime(start).TotalMicroseconds / fresh.Length;
                var bytes = (GC.GetTotalAllocatedBytes(true) - before) / (double)fresh.Length;
                Array.Sort(timings);
                Emit(new { dataset, size = (int)size, variant = name, scenario = add ? "Sustained.Add" : "Sustained.Remove",
                    requests = 1, writes = 0, round, us, bytes, ops = fresh.Length,
                    p50 = timings[timings.Length / 2], p99 = timings[(int)(timings.Length * .99)],
                    p999 = timings[(int)(timings.Length * .999)], max = timings[^1] });
            }
        Assert.Equal(items.Length, algorithm.GetByStartsWith("").Count);
        }
        finally { await algorithm.DisposeAsync(); }
        Emit(new { dataset, size = (int)size, variant = name, scenario = "Sustained.CycleIncludingDrain",
            requests = 1, writes = 0, round = 0, ops = fresh.Length * 4,
            us = Stopwatch.GetElapsedTime(totalStart).TotalMicroseconds / (fresh.Length * 4),
            bytes = (GC.GetTotalAllocatedBytes(true) - totalBefore) / (double)(fresh.Length * 4) });
    }
    return;
}
if (args[0] == "screen" || args[0] == "matrix")
{
    var dataset = args[1];
    var size = Enum.Parse<Scale>(args[2]);
    var variants = args.Length > 3 ? args[3].Split(',') : Algorithms.All.Keys.ToArray();
    var duration = args[0] == "screen" ? 35 : 120;
    var rounds = 3;
    Environment.SetEnvironmentVariable("DATASET", dataset);
    // Load and shuffle once, outside measurements. Exact seeds and queries from Dataset.cs.
    var items = Dataset.Load((int)size);
    var queries = Dataset.Queries(items);
    GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
    foreach (var name in variants)
    {
        Console.WriteLine($"BEGIN {dataset} {size} {name}");
        foreach (var rate in new[] { 0, 100, 1000 })
        {
            var bench = new SearchBenchmarks { Algorithm = name, Size = size, WritesPerSecond = rate };
            bench.Setup();
            foreach (var requests in new[] { 1, 100, 500 })
            {
                bench.Requests = requests;
                Measure("Search.StartsWith", bench.StartsWith, requests, rate);
                Measure("Search.EndsWith", bench.EndsWith, requests, rate);
                Measure("Search.Filter", bench.Filter, requests, rate);
            }
            await bench.Cleanup();
        }
        foreach (var rate in new[] { 0, 1000 })
        {
            var bench = new TypeaheadBenchmarks { Algorithm = name, Size = size };
            bench.Setup();
            using var stop = new CancellationTokenSource();
            var algorithm = (ISearchAlgorithm)typeof(TypeaheadBenchmarks)
                .GetField("_algorithm", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(bench)!;
            var all = Dataset.Load((int)size + 1000);
            var writer = rate == 0 ? Task.FromResult(0d) :
                Task.Run(() => Writer.Run(algorithm, all[..1000], all[(int)size..], rate, stop.Token));
            Measure("Typeahead.StartsWith", bench.StartsWith, 1, rate);
            Measure("Typeahead.Filter", bench.Filter, 1, rate);
            stop.Cancel();
            Console.WriteLine($"Typeahead writer: {await writer:F1} / {rate} updates/s");
            await bench.Cleanup();
        }
        foreach (var add in new[] { true, false })
        {
            var bench = new MutationBenchmarks { Algorithm = name, Size = size };
            bench.Setup();
            for (var round = -1; round < rounds; round++)
            {
                var before = GC.GetTotalAllocatedBytes(true);
                var start = Stopwatch.GetTimestamp();
                for (var i = 0; i < 1000; i++) { if (add) bench.Add(); else bench.Remove(); }
                var us = Stopwatch.GetElapsedTime(start).TotalMicroseconds / 1000;
                var bytes = (GC.GetTotalAllocatedBytes(true) - before) / 1000d;
                if (round >= 0) Emit(new { dataset, size = (int)size, variant = name, scenario = add ? "Mutation.Add" : "Mutation.Remove", requests = 1, writes = 0, round, us, bytes });
                if (add) bench.UndoAdd(); else bench.UndoRemove();
            }
            await bench.Cleanup();
        }
        for (var round = 0; round < 3; round++)
        {
            GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
            var before = GC.GetTotalAllocatedBytes(true);
            var start = Stopwatch.GetTimestamp();
            var algorithm = Algorithms.All[name](items);
            var us = Stopwatch.GetElapsedTime(start).TotalMicroseconds;
            var bytes = GC.GetTotalAllocatedBytes(true) - before;
            Emit(new { dataset, size = (int)size, variant = name, scenario = "Build", requests = 1, writes = 0, round, us, bytes });
            await algorithm.DisposeAsync();
        }
        // Full consumption detects trading a first-page gain for slow enumeration/indexing.
        await using (var algorithm = Algorithms.All[name](items))
        {
            algorithm.Remove(items[0]); algorithm.Add("EXTRA-ITEM");
            var broad = queries.Fragments[0][..1];
            Measure("Enumerate.Filter", () =>
            {
                long sum = 0; foreach (var x in algorithm.Filter(broad)) sum += x.Length; return sum;
            }, 1, 0);
            Measure("IndexAll.Filter", () =>
            {
                var hits = algorithm.Filter(broad);
                long sum = 0; for (var i = 0; i < hits.Count; i++) sum += hits[i].Length; return sum;
            }, 1, 0);
            Measure("Enumerate.Prefix", () =>
            {
                long sum = 0; foreach (var x in algorithm.GetByStartsWith("")) sum += x.Length; return sum;
            }, 1, 0);
        }

        void Measure(string scenario, Func<long> action, int requests, int writes)
        {
            var batch = scenario.StartsWith("Typeahead") ? 1000 : scenario.StartsWith("Search") ? 1000 / requests : 1;
            Timed(action, duration, batch); // warmup, whole query cycles
            for (var round = 0; round < rounds; round++)
            {
                var result = Timed(action, duration, batch);
                Emit(new { dataset, size = (int)size, variant = name, scenario, requests, writes, round, result.us, result.bytes, result.ops, result.guard });
            }
        }
    }
    return;
}
throw new ArgumentException("Expected verify, screen, matrix, bdn, or latency");

static (double us, double bytes, int ops, long guard) Timed(Func<long> action, int milliseconds, int batch)
{
    var before = GC.GetTotalAllocatedBytes(true);
    var start = Stopwatch.GetTimestamp();
    long guard = 0;
    var ops = 0;
    do
    {
        // Check the clock in batches so its cost doesn't dominate sub-microsecond queries.
        for (var i = 0; i < batch; i++) { guard += action(); ops++; }
    } while (Stopwatch.GetElapsedTime(start).TotalMilliseconds < milliseconds);
    var elapsed = Stopwatch.GetElapsedTime(start).TotalMicroseconds;
    return (elapsed / ops, (GC.GetTotalAllocatedBytes(true) - before) / (double)ops, ops, guard);
}

static void Emit(object row)
{
    var json = JsonSerializer.Serialize(row);
    File.AppendAllText(Environment.GetEnvironmentVariable("RESULTS") ?? "results.jsonl", json + "\n");
    Console.WriteLine(json);
}

static async Task Verify(string[] selected)
{
    foreach (var (name, factory) in Algorithms.All.Where(x => selected.Length == 0 || selected.Contains(x.Key)))
    {
        var existing = new AlgorithmTests();
        await existing.MatchesLinq(name);
        await existing.MatchesLinqAfterAddsAndRemoves(name);
        await existing.SurvivesSearchesDuringWrites(name);
        if (name != "Baseline")
        {
            foreach (var items in new[] { Array.Empty<string>(), new[] { "" } })
            {
                await using var empty = factory(items);
                Assert.Equal(items, empty.Filter(""));
                empty.Add("A"); empty.Remove("A");
                Assert.Equal(items, empty.Filter(""));
            }
        }
        var initial = Enumerable.Range(0, 800).Select(i => $"A{i:D6}X").Append("").Append("AAAAA").Append("Łódź😀\0").ToArray();
        await using var algorithm = factory(initial);
        var expected = initial.ToHashSet(StringComparer.Ordinal);
        var random = new Random(11);
        for (var i = 0; i < 3000; i++)
        {
            var item = $"A{random.Next(1600):D6}X";
            if (random.Next(2) == 0) { algorithm.Add(item); expected.Add(item); }
            else { algorithm.Remove(item); expected.Remove(item); }
            if (i % 100 == 0)
                foreach (var q in new[] { "", "A", "0", "X", "AAA", "\0", "😀", "MISS", "A000" })
                {
                    Check(algorithm.GetByStartsWith(q), expected.Where(x => x.StartsWith(q, StringComparison.Ordinal)));
                    Check(algorithm.GetByEndsWith(q), expected.Where(x => x.EndsWith(q, StringComparison.Ordinal)));
                    Check(algorithm.Filter(q), expected.Where(x => x.Contains(q, StringComparison.Ordinal)));
                }
        }
        algorithm.Add("ASTABLEX");
        expected.Add("ASTABLEX");
        var snapshots = new[] { algorithm.GetByStartsWith("A"), algorithm.GetByEndsWith("X"), algorithm.Filter("A") };
        var snapshotExpected = new[]
        {
            expected.Where(x => x.StartsWith("A", StringComparison.Ordinal)).ToArray(),
            expected.Where(x => x.EndsWith("X", StringComparison.Ordinal)).ToArray(),
            expected.Where(x => x.Contains("A", StringComparison.Ordinal)).ToArray()
        };
        using var stop = new CancellationTokenSource();
        var readers = Enumerable.Range(0, 3).Select(_ => Task.Run(() =>
        {
            while (!stop.IsCancellationRequested)
                foreach (var hits in new[] { algorithm.GetByStartsWith("A"), algorithm.GetByEndsWith("X"), algorithm.Filter("A") })
                {
                    var all = hits.ToArray();
                    Assert.Equal(hits.Count, all.Length);
                    Assert.Equal(all.Length, all.Distinct().Count());
                }
        })).ToArray();
        await Task.WhenAll(Enumerable.Range(0, 4).Select(writer => Task.Run(() =>
        {
            for (var i = 0; i < 500; i++)
            {
                var item = $"AW{writer}-{i:D5}X";
                algorithm.Add(item);
                Assert.Contains(item, algorithm.GetByStartsWith(item));
                Assert.Contains(item, algorithm.GetByEndsWith(item));
                Assert.Contains(item, algorithm.Filter(item));
                if (i % 2 == 0)
                {
                    algorithm.Remove(item);
                    Assert.Empty(algorithm.GetByStartsWith(item));
                    Assert.Empty(algorithm.GetByEndsWith(item));
                    Assert.Empty(algorithm.Filter(item));
                }
            }
        })));
        stop.Cancel();
        await Task.WhenAll(readers);
        Parallel.For(0, 10, _ =>
        {
            for (var i = 0; i < snapshots.Length; i++) Check(snapshots[i], snapshotExpected[i]);
        });
        if (name != "Baseline") Assert.False(algorithm.GetByStartsWith("Ł") is IList<string>);
        Console.WriteLine($"PASS {name}: original tests; randomized/indexed results; concurrent writers/readers; unmaterialized retained snapshots" +
                          (name == "Baseline" ? "; known empty-input failure excluded" : "; empty inputs"));
    }
}

static void Check(IReadOnlyList<string> hits, IEnumerable<string> expected)
{
    var actual = hits.ToArray();
    Assert.Equal(expected.Order(StringComparer.Ordinal), actual.Order(StringComparer.Ordinal));
    Assert.Equal(actual.Length, hits.Count);
    // Exercises both sides of the 64-result page and repeatedly accesses fallback cache.
    foreach (var i in new[] { 0, 1, 9, 63, 64, 100, hits.Count - 1 }.Where(i => i >= 0 && i < hits.Count))
        Assert.Equal(actual[i], hits[i]);
}
