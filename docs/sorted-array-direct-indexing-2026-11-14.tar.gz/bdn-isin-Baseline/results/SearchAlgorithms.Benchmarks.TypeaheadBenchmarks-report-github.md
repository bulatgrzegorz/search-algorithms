```

BenchmarkDotNet v0.15.8, macOS Tahoe 26.5.2 (25F84) [Darwin 25.5.0]
Unknown processor
.NET SDK 11.0.100
  [Host] : .NET 11.0.0 (11.0.0, 11.0.26.53018), Arm64 RyuJIT armv8.0-a

Job=ShortRun  Toolchain=InProcessEmitToolchain  IterationCount=5  
IterationTime=200ms  LaunchCount=1  WarmupCount=3  

```
| Method     | WritesPerSecond | Algorithm | Size   | Mean            | Error            | StdDev          | Gen0     | Gen1     | Gen2    | Allocated |
|----------- |---------------- |---------- |------- |----------------:|-----------------:|----------------:|---------:|---------:|--------:|----------:|
| **StartsWith** | **0**               | **Baseline**  | **Small**  |        **486.4 ns** |          **9.63 ns** |         **2.50 ns** |   **0.0292** |        **-** |       **-** |     **245 B** |
| **StartsWith** | **0**               | **Baseline**  | **Medium** |        **607.5 ns** |          **9.66 ns** |         **2.51 ns** |   **0.0271** |        **-** |       **-** |     **245 B** |
| **StartsWith** | **0**               | **Baseline**  | **Huge**   |        **815.4 ns** |         **82.48 ns** |        **12.76 ns** |   **0.0264** |        **-** |       **-** |     **245 B** |
| **StartsWith** | **1000**            | **Baseline**  | **Small**  |     **22,337.2 ns** |     **13,998.14 ns** |     **3,635.27 ns** |  **10.8548** |   **0.1696** |  **0.0848** |   **91283 B** |
| **StartsWith** | **1000**            | **Baseline**  | **Medium** |  **3,254,474.6 ns** |  **4,926,732.34 ns** | **1,279,456.75 ns** | **112.5000** | **112.5000** | **50.0000** |  **955911 B** |
| **StartsWith** | **1000**            | **Baseline**  | **Huge**   | **10,896,773.3 ns** | **10,388,385.02 ns** | **2,697,830.61 ns** | **156.2500** |  **93.7500** | **93.7500** | **9086093 B** |
