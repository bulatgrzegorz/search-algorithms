from pathlib import Path
import subprocess,os
r=Path(__file__).parent
dll=str(r/'bin/Release/net11.0/Experiments.dll')
for ds in ['isin','names']:
 for size in ['Small','Medium']:
  for variant in ['Baseline','Changed']:
   name=f'matrix-{ds}-{size}-{variant}'
   print('START '+name,flush=True)
   with (r/(name+'.log')).open('w') as f:
    subprocess.run(['dotnet',dll,'matrix',ds,size,variant],env=dict(os.environ,RESULTS=str(r/'results.jsonl')),stdout=f,stderr=subprocess.STDOUT,check=True)
   print('DONE '+name,flush=True)
for ds in ['isin','names']:
 for variant in ['Baseline','Changed']:
  name=f'bdn-{ds}-{variant}'
  print('START '+name,flush=True)
  with (r/(name+'.log')).open('w') as f:
   subprocess.run(['dotnet',dll,'bdn','--inProcess','--job','short','--warmupCount','3','--iterationCount','5','--iterationTime','200','--filter','*SearchAlgorithms.Benchmarks.TypeaheadBenchmarks.StartsWith*','--artifacts',str(r/name)],cwd=r,env=dict(os.environ,DATASET=ds,ALGORITHM=variant),stdout=f,stderr=subprocess.STDOUT,check=True)
  print('DONE '+name,flush=True)
