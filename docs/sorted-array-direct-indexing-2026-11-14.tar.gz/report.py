from pathlib import Path
from collections import defaultdict
import json,csv,statistics,tarfile
r=Path(__file__).parent
repo=Path('/Users/grzegorzbulat/Repos/search-algorithms')
groups=defaultdict(list)
rows=[json.loads(s) for s in (r/'results.jsonl').read_text().splitlines()]
for x in rows:groups[tuple(x[k] for k in ['dataset','size','variant','scenario','requests','writes'])].append(x)
assert len(rows)==888 and len(groups)==296 and all(len(v)==3 for v in groups.values())
checks=defaultdict(set)
for x in rows:
 if x['writes']==0 and 'guard' in x:checks[(x['dataset'],x['size'],x['scenario'],x['requests'])].add(round(x['guard']/x['ops'],8))
assert all(len(v)==1 for v in checks.values())
m={k:(statistics.median(x['us'] for x in v),statistics.median(x['bytes'] for x in v)) for k,v in groups.items()}
def table(h,rs):
 return '\n'.join(['| '+' | '.join(h)+' |','|'+'|'.join(['---']*len(h))+'|']+['| '+' | '.join(map(str,row))+' |' for row in rs])+'\n'
def comparison(scenarios):
 out=[]
 for k,a in sorted(m.items()):
  ds,size,variant,sc,req,rate=k
  if variant!='Changed' or sc not in scenarios:continue
  b=m[(ds,size,'Baseline',sc,req,rate)]
  out.append([ds,f'{size:,}',sc,req,rate,f'{b[0]:.3f}',f'{a[0]:.3f}',f'{b[0]/a[0]:.2f}x',f'{b[1]:,.0f}',f'{a[1]:,.0f}'])
 return table(['Data','Items','Scenario','Requests','Updates/s','Before us','After us','Speedup','Before B','After B'],out)
with (r/'summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['dataset','size','variant','scenario','requests','updates_per_second','median_us','median_bytes'])
 for k,v in sorted(m.items()):w.writerow([*k,*v])
bdn=[]
for ds in ['isin','names']:
 for variant in ['Baseline','Changed']:
  p=r/f'bdn-{ds}-{variant}/results/SearchAlgorithms.Benchmarks.TypeaheadBenchmarks-report.csv'
  values=list(csv.DictReader(p.open()))
  assert len(values)==6 and all(x['Mean']!='NA' for x in values)
  for x in values:bdn.append([ds,variant,x['Size'],x['WritesPerSecond'],x['Mean'],x['Error'],x['Allocated']])
doc="""# Direct merged indexing: applied change — 2026-11-14

Implemented only the direct merged-indexing recommendation in SortedArrayIndex.Merged. First 64 indexed reads walk immutable merge events, larger indexed reads and enumeration materialize the existing bulk-copy result. Volatile.Read and Interlocked.CompareExchange publish a completed cache safely. Count and snapshot publication retain their behavior. Invalid indexes are rejected before allocating a result.

TypeaheadBenchmarks now includes WritesPerSecond=0/1000, using the existing Writer.Run. The old no-write-only case did not exercise this change.

## Validation

Five tests passed: the existing three SortedArrayIndex algorithm tests and two new prefix/suffix cases. The new cases check index order and bounds before materialization, access across the 64-hit boundary, concurrent cache creation/enumeration, and stable results while writes cross merge thresholds.

## Before/after method

- Before: exact source from HEAD (3c7ea4a), copied as Baseline; after: linked current production SortedArrayIndex.cs. No Filter changes, merge threshold changes, empty-input fixes or read-only wrapper changes were included.
- macOS Arm64, .NET 11.0.0, Release. Real ISIN and name datasets; original shuffle/query seeds.
- Linked the actual Benchmarks.cs classes. Matrix: 10k and 100k items, three searches, 1/100/500 requests, 0/100/1000 updates/s, typeahead 0/1000, Add/Remove, Build and full consumption controls.
- 296 scenario/variant combinations, 888 measured samples. Medians below; each timed sample completes whole cycles of all 1,000 seeded queries. All no-write result checksums matched.
- Each variant/dataset/size ran in a separate process. Dataset loading is cached outside timing with only the requested sample plus churn items retained.
- Matrix allocation uses process-wide counters and includes writer allocation during writes. Typeahead time is per complete typed query, parallel search time per batch. One update is a Remove+Add pair.
- BenchmarkDotNet 0.15.8 confirmation uses the updated TypeaheadBenchmarks.StartsWith for both datasets at 10k/100k/1M, with 0/1000 updates/s: 24 cases. InProcessEmitToolchain is required because this bundled version's default subprocess toolchain does not recognize .NET 11. Separate outer process per variant/dataset; 3 warmups, 5 measured iterations, 200 ms. Tail-heavy cases have wide error intervals; large speedups are directional, not precise production guarantees.
- Build and mutation controls can vary substantially between separate runs despite unchanged work. They do not establish a build/write optimization.

## Typeahead
"""+comparison(['Typeahead.StartsWith','Typeahead.Filter'])+"""
## Search latency and concurrent batches

These read Count rather than result indexes, so this change is not expected to improve them systematically.
"""+comparison(['Search.StartsWith','Search.EndsWith','Search.Filter'])+"""
## Build, mutations and complete result reads
"""+comparison(['Build','Mutation.Add','Mutation.Remove','Enumerate.Prefix','Enumerate.Filter','IndexAll.Filter'])+"""
## BenchmarkDotNet confirmation

Error is the interval reported by BenchmarkDotNet. Some under-write cases are noisy. Consult the raw reports in the archive for GC statistics and writer achievement.
"""+table(['Data','Variant','Size','Updates/s','Mean','Error','Allocated'],bdn)+"""
## Artifacts and reproduction

Companion archive: sorted-array-direct-indexing-2026-11-14.tar.gz. Contains baseline source, current-source snapshot, linked-source harness, raw JSONL, summary.csv, benchmark logs and BenchmarkDotNet reports. Working directory: /private/tmp/sorted-array-direct.pzUfE6.

The harness uses the current checkout's benchmark/test files and local data. Build Experiments.csproj in Release, then run run.py for the recorded matrix/BenchmarkDotNet sequence. Baseline.cs preserves the pre-change implementation. changed-source.cs.txt preserves the measured implementation.

To run the new benchmark scenario directly from this repository, set ALGORITHM=SortedArrayIndex and DATASET=isin or names, then run:
    
    dotnet run --project benchmarks/SearchAlgorithms.Benchmarks -c Release -- --inProcess --job short --filter '*TypeaheadBenchmarks.StartsWith*'

Focused tests:
    
    dotnet test tests/SearchAlgorithms.Tests --filter 'FullyQualifiedName~SortedArrayIndexTests|DisplayName~SortedArrayIndex'

Direct indexing is O(matching pending edits) per access for the first page; the cutoff avoids repeatedly walking edits when reading later positions. Cache initialization can still allocate duplicate copies under a race, but all published cache arrays are complete and equivalent.
"""
(repo/'docs/results-sorted-array-direct-indexing-2026-11-14.md').write_text(doc)
(r/'changed-source.cs.txt').write_text((repo/'src/SearchAlgorithms/SortedArrayIndex.cs').read_text())
with tarfile.open(repo/'docs/sorted-array-direct-indexing-2026-11-14.tar.gz','w:gz') as tar:
 for p in r.rglob('*'):
  if not p.is_file() or any(part in ['bin','obj'] for part in p.relative_to(r).parts):continue
  if p.suffix in ['.cs','.py','.csproj','.jsonl','.log','.csv','.md','.txt']:tar.add(p,arcname=str(p.relative_to(r)))
print('Report/archive written. Matrix checksums and sample counts verified.')
